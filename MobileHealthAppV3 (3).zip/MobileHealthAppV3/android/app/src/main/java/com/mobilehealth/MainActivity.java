package com.mobilehealth;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
