
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-fcm-with-dependecy-updated.FCMPlugin",
          "file": "plugins/cordova-plugin-fcm-with-dependecy-updated/www/FCMPlugin.js",
          "pluginId": "cordova-plugin-fcm-with-dependecy-updated",
        "clobbers": [
          "FCM"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-fcm-with-dependecy-updated": "7.8.0"
    };
    // BOTTOM OF METADATA
    });
    