package com.gae.scaffolder.plugin.interfaces;

public interface OnFinishedListener<TResult> {
    void success(TResult result);
}
