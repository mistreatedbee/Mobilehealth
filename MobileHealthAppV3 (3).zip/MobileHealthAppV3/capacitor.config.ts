import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mobilehealth',
  appName: 'mobile-health-app',
  webDir: 'dist'
};

export default config;
