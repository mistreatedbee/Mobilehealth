import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { appointmentAPI } from "../../services/api";
import { Appointment, Patient } from "../../types";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";

export function AppointmentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);

  useEffect(() => {
    async function loadAppointment() {
      if (!id) return;

      try {
        const data = await appointmentAPI.getById(id);

        // ✅ Appointment is returned with patient populated
        setAppointment(data);
        setPatient(data.patientId as unknown as Patient);

      } catch (err) {
        console.log("❌ Failed to load appointment", err);
      }
    }

    loadAppointment();
  }, [id]);

  if (!appointment || !patient) {
    return (
      <Card className="p-12 text-center">
        <p className="text-gray-500">Appointment not found</p>
        <Button onClick={() => navigate("/doctor/dashboard")} className="mt-4">
          Back to Dashboard
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Appointment Details</h1>
        <Button variant="secondary" onClick={() => navigate("/doctor/dashboard")}>
          Back
        </Button>
      </div>

      {/* Patient & Appointment Info */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <h2 className="text-xl font-semibold">
            {patient.firstName} {patient.lastName}
          </h2>
          <Badge
            variant={
              appointment.status === "approved"
                ? "success"
                : appointment.status === "declined"
                ? "danger"
                : "warning"
            }
          >
            {appointment.status}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Appointment Info */}
          <div>
            <h3 className="font-semibold mb-3">Appointment Information</h3>
            <div className="space-y-2 text-sm">
              <p><span className="text-gray-600">Date:</span> <span className="font-medium">{new Date(appointment.date).toLocaleDateString()}</span></p>
              <p><span className="text-gray-600">Time:</span> <span className="font-medium">{appointment.time}</span></p>
              <p><span className="text-gray-600">Type:</span> <span className="font-medium capitalize">{appointment.type}</span></p>
              <p><span className="text-gray-600">Reason:</span> <span className="font-medium">{appointment.reason}</span></p>
            </div>
          </div>

          {/* Patient Contact Info */}
          <div>
            <h3 className="font-semibold mb-3">Patient Contact</h3>
            <div className="space-y-2 text-sm">
              <p><span className="text-gray-600">Email:</span> <span className="font-medium">{patient.email}</span></p>

              {patient.phone && (
                <p><span className="text-gray-600">Phone:</span> <span className="font-medium">{patient.phone}</span></p>
              )}

              {patient.emergencyContactName && (
                <div className="mt-3 pt-3 border-t">
                  <p><span className="text-gray-600">Emergency Contact:</span> <span className="font-medium">{patient.emergencyContactName}</span></p>
                  {patient.emergencyContactPhone && (
                    <p><span className="text-gray-600">Emergency Phone:</span> <span className="font-medium">{patient.emergencyContactPhone}</span></p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Medical Profile */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Patient Medical Profile</h3>

        <div className="text-sm space-y-2">
          <p><span className="text-gray-600">Age:</span> {patient.age ?? "Not provided"}</p>
          <p><span className="text-gray-600">Blood Type:</span> {patient.bloodType ?? "Not provided"}</p>
          <p><span className="text-gray-600">Medical History:</span></p>
          <p className="text-gray-700 whitespace-pre-line">
            {patient.medicalHistory || "No medical history provided."}
          </p>
        </div>
      </Card>

    </div>
  );
}
