import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

import { Toaster, toast } from "react-hot-toast";

import { messaging } from "./firebase";
import { getToken, onMessage } from "firebase/messaging";
import { Capacitor } from "@capacitor/core";

import { PushNotifications } from '@capacitor/push-notifications';
import { FCM } from '@capacitor-community/fcm';

const API_URL = import.meta.env.VITE_API_URL || "http://10.0.2.2:5000";

// Auth Pages
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { DoctorRegister } from './pages/doctor/DoctorRegister';

// Patient Pages
import { PatientLayout } from './components/layout/PatientLayout';
import { PatientDashboard } from './pages/patient/PatientDashboard';
import { PatientProfile } from './pages/patient/PatientProfile';
import { DoctorList } from './pages/patient/DoctorList';
import { BookAppointment } from './pages/patient/BookAppointment';
import { PatientAppointments } from './pages/patient/PatientAppointments';
import { PatientPrescriptions } from './pages/patient/PatientPrescriptions';

// Doctor Pages
import { DoctorLayout } from './components/layout/DoctorLayout';
import { DoctorDashboard } from './pages/doctor/DoctorDashboard';
import { AppointmentDetail } from './pages/doctor/AppointmentDetail';
import { IssuePrescription } from './pages/doctor/IssuePrescription';

// Admin Pages
import { AdminLayout } from './components/layout/AdminLayout';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { ManagePatients } from './pages/admin/ManagePatients';
import { ManageDoctors } from './pages/admin/ManageDoctors';
import { ManageAppointments } from './pages/admin/ManageAppointments';

function ProtectedRoute({ children, allowedRole }: { children: React.ReactNode; allowedRole: string }) {
  const { user, isLoading } = useAuth();

  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (user.role !== allowedRole) return <Navigate to="/login" />;

  return <>{children}</>;
}

function AppRoutes() {
  const { user, isLoading } = useAuth();

  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={`/${user.role}/dashboard`} /> : <Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/doctor/register" element={<DoctorRegister />} />

      {/* Patient */}
      <Route path="/patient/*" element={
        <ProtectedRoute allowedRole="patient">
          <PatientLayout>
            <Routes>
              <Route path="/dashboard" element={<PatientDashboard />} />
              <Route path="/profile" element={<PatientProfile />} />
              <Route path="/doctors" element={<DoctorList />} />
              <Route path="/book-appointment" element={<BookAppointment />} />
              <Route path="/appointments" element={<PatientAppointments />} />
              <Route path="/prescriptions" element={<PatientPrescriptions />} />
            </Routes>
          </PatientLayout>
        </ProtectedRoute>
      } />

      {/* Doctor */}
      <Route path="/doctor/*" element={
        <ProtectedRoute allowedRole="doctor">
          <DoctorLayout>
            <Routes>
              <Route path="/dashboard" element={<DoctorDashboard />} />
              <Route path="/appointments" element={<DoctorDashboard />} />
              <Route path="/appointments/:id" element={<AppointmentDetail />} />
              <Route path="/appointments/:id/prescription" element={<IssuePrescription />} />
            </Routes>
          </DoctorLayout>
        </ProtectedRoute>
      } />

      {/* Admin */}
      <Route path="/admin/*" element={
        <ProtectedRoute allowedRole="admin">
          <AdminLayout>
            <Routes>
              <Route path="/dashboard" element={<AdminDashboard />} />
              <Route path="/patients" element={<ManagePatients />} />
              <Route path="/doctors" element={<ManageDoctors />} />
              <Route path="/appointments" element={<ManageAppointments />} />
            </Routes>
          </AdminLayout>
        </ProtectedRoute>
      } />

      <Route path="/" element={<Navigate to="/login" />} />
    </Routes>
  );
}

function PushHandler() {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Web Push
    if (Capacitor.getPlatform() === "web") {
      if (!messaging) return;

      Notification.requestPermission().then(async (permission) => {
        if (permission === "granted") {
          try {
            const token = await getToken(messaging, {
              vapidKey: "BOtgES5rWVy7kqGg1rWFK91iPuW9tRBQ5GTcI_9qgKSLbFJq7YcnnLX_7yzDQye_JYW8KjW9HftwGF2xEfACgpI",
            });

            if (user?._id) {
              await fetch(`${API_URL}/push/save-token`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId: user._id, token }),
              });
            }

          } catch (err) {
            console.log("Web push token failed:", err);
          }
        }
      });

      onMessage(messaging, (payload) => {
        toast(`${payload.notification?.title ?? "Notification"}: ${payload.notification?.body ?? ""}`);
      });

      return;
    }

    // Mobile Push
    async function setupPush() {
      try {
        const perm = await PushNotifications.requestPermissions();
        if (perm.receive === "granted") await PushNotifications.register();

        PushNotifications.addListener("registration", async (token) => {
          if (user?._id) {
            await fetch(`${API_URL}/push/save-token`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ userId: user._id, token: token.value }),
            });
          }

          try {
            await FCM.subscribeTo({ topic: "general" });
          } catch (err) {
            console.log("FCM subscribe failed:", err);
          }
        });

        PushNotifications.addListener("pushNotificationReceived", (notification) => {
          toast(`${notification.notification?.title ?? "Notification"}: ${notification.notification?.body ?? ""}`);
        });

      } catch (err) {
        console.log("Mobile Push setup error:", err);
      }
    }

    setupPush();
  }, [user]);

  return null;
}

export function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" />
        <PushHandler />
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
