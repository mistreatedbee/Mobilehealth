import React, { ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { HomeIcon, UserIcon, StethoscopeIcon, CalendarIcon, FileTextIcon, LogOutIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
interface PatientLayoutProps {
  children: ReactNode;
}
export function PatientLayout({
  children
}: PatientLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const {
    logout
  } = useAuth();
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  const navItems = [{
    path: '/patient/dashboard',
    icon: HomeIcon,
    label: 'Dashboard'
  }, {
    path: '/patient/profile',
    icon: UserIcon,
    label: 'Profile'
  }, {
    path: '/patient/doctors',
    icon: StethoscopeIcon,
    label: 'Find Doctors'
  }, {
    path: '/patient/appointments',
    icon: CalendarIcon,
    label: 'Appointments'
  }, {
    path: '/patient/prescriptions',
    icon: FileTextIcon,
    label: 'Prescriptions'
  }];
  return <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-blue-600">HealthApp</h1>
            </div>
            <button onClick={handleLogout} className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
              <LogOutIcon className="w-5 h-5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          <aside className="w-full md:w-64 flex-shrink-0">
            <nav className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <ul className="space-y-2">
                {navItems.map(item => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return <li key={item.path}>
                      <Link to={item.path} className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${isActive ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>
                        <Icon className="w-5 h-5" />
                        <span>{item.label}</span>
                      </Link>
                    </li>;
              })}
              </ul>
            </nav>
          </aside>

          <main className="flex-1">{children}</main>
        </div>
      </div>
    </div>;
}