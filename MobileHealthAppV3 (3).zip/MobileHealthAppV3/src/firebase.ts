import { initializeApp } from "firebase/app";
import { getMessaging } from "firebase/messaging";

// ✅ Your Firebase config (copy exactly from Firebase Console)
const firebaseConfig = {
  apiKey: "AIzaSyAwaHeEJppwyRnzTzgrNhBnvdg7na8948M",
  authDomain: "mobilehealth-a2112.firebaseapp.com",
  projectId: "mobilehealth-a2112",
  storageBucket: "mobilehealth-a2112.firebasestorage.app",
  messagingSenderId: "431964780507",
  appId: "1:431964780507:web:da9a556813c6acb06cd9fe",
  measurementId: "G-DTD9DYJSXL"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);

// ✅ Initialize Messaging (Web Push)
export const messaging = getMessaging(app);
