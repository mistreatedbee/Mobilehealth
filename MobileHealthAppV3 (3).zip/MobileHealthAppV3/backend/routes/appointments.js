import express from "express";
import Appointment from "../models/Appointment.js";
import User from "../models/User.js";
import { sendNotification } from "../utils/sendNotification.js";
import mongoose from "mongoose";

const router = express.Router();

/* CREATE */
router.post("/", async (req, res) => {
  try {
    const { patientId, doctorId, type, date, time, reason } = req.body;

    const appt = await Appointment.create({
      patientId: new mongoose.Types.ObjectId(patientId),
      doctorId: new mongoose.Types.ObjectId(doctorId),
      type,
      date: new Date(date),
      time,
      reason,
      status: "pending",
    });

    res.json({ success: true, appointment: appt });
  } catch (e) {
    console.log("Create appointment error:", e.message);
    res.status(500).json({ success: false, message: "Error creating appointment" });
  }
});

/* LIST ALL (ADMIN) */
router.get("/", async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};

  const list = await Appointment.find(filter)
    .populate("patientId", "firstName lastName email phone city province")
    .populate("doctorId", "firstName lastName specialty clinicName city province phone")
    .sort({ createdAt: -1 });

  res.json({ success: true, appointments: list });
});

/* BY PATIENT (Return Full Doctor Details) */
router.get("/patient/:id", async (req, res) => {
  const list = await Appointment.find({ patientId: req.params.id })
    .populate("doctorId", "firstName lastName specialty clinicName phone email city province")
    .sort({ createdAt: -1 });

  res.json({ success: true, appointments: list });
});

/* BY DOCTOR (Return Full Patient Details) */
router.get("/doctor/:id", async (req, res) => {
  try {
    const list = await Appointment.find({ doctorId: req.params.id })
      .populate("patientId", "firstName lastName email phone city province bloodType age medicalHistory emergencyContactName emergencyContactPhone")
      .sort({ createdAt: -1 });

    res.json({ success: true, appointments: list });
  } catch (err) {
    console.log("❌ Get doctor appointments error:", err);
    res.status(500).json({ success: false, message: "Failed to fetch doctor appointments" });
  }
});

/* GET ONE */
router.get("/:id", async (req, res) => {
  const appt = await Appointment.findById(req.params.id)
    .populate("doctorId", "firstName lastName specialty clinicName phone city province")
    .populate("patientId", "firstName lastName email phone city province");

  if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });

  res.json({ success: true, appointment: appt });
});

/* UPDATE */
router.put("/:id", async (req, res) => {
  const updated = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json({ success: true, appointment: updated });
});

/* UPDATE STATUS + NOTIFY */
router.put("/:id/status", async (req, res) => {
  try {
    const { status } = req.body;

    const updated = await Appointment.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ success: false, message: "Appointment not found" });
    }

    const patient = await User.findById(updated.patientId);

    if (patient?.pushToken) {
      await sendNotification(
        patient.pushToken,
        "Appointment Update",
        `Your appointment has been ${status}.`,
        { appointmentId: String(updated._id) }
      );
    }

    res.json({ success: true, appointment: updated });
  } catch (err) {
    console.log("Update status error:", err.message);
    res.status(500).json({ success: false });
  }
});

/* CANCEL */
router.put("/:id/cancel", async (req, res) => {
  const updated = await Appointment.findByIdAndUpdate(
    req.params.id,
    { status: "cancelled" },
    { new: true }
  );

  res.json({ success: true, appointment: updated });
});

/* GENERATE VIDEO LINK */
router.post("/:id/video-link", async (req, res) => {
  try {
    const appointmentId = req.params.id;
    const roomName = `mobilehealth-${appointmentId}`;
    const link = `https://meet.jit.si/${roomName}`;

    const updated = await Appointment.findByIdAndUpdate(
      appointmentId,
      { videoCallLink: link },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ success: false, message: "Appointment not found" });
    }

    res.json({ success: true, link, appointment: updated });

  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to generate video link" });
  }
});


/* DELETE */
router.delete("/:id", async (req, res) => {
  await Appointment.findByIdAndDelete(req.params.id);
  res.json({ success: true, message: "Deleted" });
});

export default router;
