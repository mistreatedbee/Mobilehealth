import express from "express";
import mongoose from "mongoose";
import User from "../models/User.js";

const router = express.Router();


// ✅ Get patient by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid patient ID" });
    }

    const patient = await User.findById(id);

    if (!patient || patient.role !== "patient") {
      return res.status(404).json({ message: "Patient not found" });
    }

    res.status(200).json(patient);
  } catch (err) {
    console.error("Error fetching patient:", err);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


// ✅ Update patient profile
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid patient ID" });
    }

    const updatedPatient = await User.findByIdAndUpdate(
      id,
      req.body,
      {
        new: true,            // ✅ return updated patient
        runValidators: true   // ✅ make Mongoose apply schema rules
      }
    );

    if (!updatedPatient) {
      return res.status(404).json({ message: "Patient not found" });
    }

    res.status(200).json(updatedPatient);
  } catch (err) {
    console.error("Error updating patient profile:", err);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


// ✅ Delete patient account
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: "Invalid patient ID" });
    }

    await User.findByIdAndDelete(id);

    res.status(204).send();  // No content
  } catch (err) {
    console.error("Error deleting patient:", err);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


export default router;
